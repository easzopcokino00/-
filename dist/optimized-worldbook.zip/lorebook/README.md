# Lorebook

This is the main lorebook directory containing world-building content.

## Contents

- Characters and their backstories
- World history and timeline
- Locations and geography
- Magic systems and rules
- Cultural information

This directory serves as the central repository for all world-building documentation.