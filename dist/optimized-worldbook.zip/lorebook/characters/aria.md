# Main Character: Aria

## Background
Aria is a skilled mage from the northern realms, known for her exceptional control over elemental magic.

## Abilities
- Fire manipulation
- Ice spells
- Lightning control

## Relationships
- Mentor: Elder Magnus
- Rival: Shadowbane
- Ally: Captain Valerius

## Story Arc
Aria's journey begins in the frozen tunders and leads her to the heart of the magical academy.